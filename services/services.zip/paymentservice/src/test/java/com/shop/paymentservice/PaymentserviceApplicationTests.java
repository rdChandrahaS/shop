package com.shop.paymentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
