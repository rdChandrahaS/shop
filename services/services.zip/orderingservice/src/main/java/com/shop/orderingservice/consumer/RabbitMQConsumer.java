package com.shop.orderingservice.consumer;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import com.shop.orderingservice.dto.OrderEventDTO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RabbitMQConsumer {
	
	@RabbitListener(queues = {"${rabbitmq.queue.name}"} )
	public void consume(OrderEventDTO orderEvent) {
		log.info("Order is recieved.Order ID: {}, Status: {}",orderEvent.getOrderId(), orderEvent.getStatus());
	}
}
